let a = prompt("")
if (a<=16){
    alert('ukajon tu xoli yosh')
}else if (a<=18){
    alert('daroku')
}else if (a<=20){
    alert('pir')
}else{
    alert('tu chi kermi?.')
}
